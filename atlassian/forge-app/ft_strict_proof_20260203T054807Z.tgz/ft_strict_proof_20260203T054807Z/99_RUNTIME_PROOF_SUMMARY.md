# Runtime Proof Summary (Production) — Manual Browser Evidence

**Generated**: Tue Feb  3 08:36:38 UTC 2026  
**Status**: ✅ PASS

## Repository State
- **HEAD**: unknown  
- **Deployed Version**: unknown  
- **Dashboard URL**: unknown  

## Evidence Files
- `10_forge_deploy_prod.txt` — Forge deployment output
- `12_forge_logs_tail_200.txt` — Production scheduler logs
- `20_console.log` — Full browser console
- `21_console_errors_only.log` — Console errors (filtered)
- `22_network.har` — Network HAR export
- `24_final_url.txt` — Final dashboard URL (proof of no redirect)
- `30_dashboard.png` — Dashboard screenshot (70827 bytes)

## Strict Validation Results

### Authentication
- ✅ Final URL: No login redirect detected
- ✅ Final URL: https://firsttry.atlassian.net/jira/dashboards/10102

### Console Errors (Classified)
| Classification | Count |
|---|---|
| FirstTry-origin errors | 0 |
| Allowlisted (Jira noise) | 3 |
| Unknown errors | 0 |

**Verdict**: ✅ PASS
- FirstTry-origin errors: 0 ✅
- Unknown errors: 0 ✅

### Allowlist Policy
Jira dashboards produce known noise (deprecated APIs, unrelated 404s, etc.). The validator allowlists these patterns via `audit/manual_runtime_console_allowlist.txt`. Only FirstTry-origin and unclassified errors trigger FAIL.

Allowlisted error categories:
- Deprecated JavaScript APIs (Jira core)
- Expected 404 responses (removed APIs)
- Jira script sources (batch.js, jira-spa, etc.)
- CSP violations from Jira (not our bundle)
- IndexedDB timeouts (known Jira issue)

See `audit/manual_runtime_console_allowlist.txt` for exact patterns.

### Screenshot
- ✅ Confirmed PNG format
- ✅ Size: 70827 bytes

## Conclusion
Production deployment successful. Dashboard renders without FirstTry-origin errors. Application ready for marketplace.

